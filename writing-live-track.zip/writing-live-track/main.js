const { Plugin, Notice, Setting, normalizePath, TFile } = require("obsidian");
const { EditorView } = require("@codemirror/view");
const { Transaction } = require("@codemirror/state");

const DEFAULT_SETTINGS = {
  globalEnabled: true,
  logFolderName: "log",
  autoInsertLink: true,

  // MOVE detection window (cut + paste)
  moveWindowMs: 4000,

  // batching writes
  flushMs: 250,

  // snippet clipping
  maxSnippet: 260,

  // ignore edits in frontmatter
  skipFrontmatter: true,

  // TYPE = sentence-level buffer (flush on punctuation/newline/pause)
  sentenceGapMs: 800,

  // DEL = merge window (flush on pause)
  editGapMs: 250,
};

module.exports = class WritingLiveTrack extends Plugin {
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());

    this.internalEdit = false;

    // write batching per file
    this.writeQueue = new Map(); // filePath -> { lines: string[], timer: number|null, writing: boolean }

    // TYPE sentence buffer per file
    this.sentAgg = new Map(); // filePath -> { text: string, where: string, lastAt: number }

    // DEL buffer per file
    this.delAgg = new Map(); // filePath -> { text: string, where: string, lastAt: number }

    // pending CUT for MOVE recognition
    this.pendingCut = null; // { text, fromWhere, at, filePath }

    // sentence end markers
    this.sentenceEndRe = /[.!?。！？]/;

    // colors (timestamp cyan, position purple, + green, - red, = yellow)
    this.colors = {
      ts: "#19c6c6",
      pos: "#b26cff",
      plus: "#36d36d",
      minus: "#ff4d4d",
      eq: "#ffd34d",
      action: "#e6e6e6",
    };

    // Command: toggle writeTrack for current note
    this.addCommand({
      id: "writing-live-track-toggle",
      name: "Writing Live Track: Toggle tracking for current note",
      callback: async () => {
        const file = this.app.workspace.getActiveFile();
        if (!file) return;

        this.internalEdit = true;
        await this.app.fileManager.processFrontMatter(file, (fm) => {
          if (fm.writeTrack === true) delete fm.writeTrack;
          else fm.writeTrack = true;
        });
        setTimeout(() => (this.internalEdit = false), 0);

        const on = await this.isTrackingOnByVaultRead(file);
        new Notice(`Writing Live Track: ${on ? "ON" : "OFF"}`);

        if (on) {
          await this.getOrCreateLogFile(file);
          if (this.settings.autoInsertLink) {
            this.internalEdit = true;
            try {
              await this.ensureLogLinkInNote(file);
            } finally {
              setTimeout(() => (this.internalEdit = false), 0);
            }
          }
        }
      },
    });

    this.addSettingTab(new WritingLiveTrackSettingTab(this.app, this));

    // CM6 listener
    this.registerEditorExtension(
      EditorView.updateListener.of((update) => {
        try {
          if (!update.docChanged) return;

          const file = this.app.workspace.getActiveFile();
          if (!file) return;
          if (this.internalEdit) return;
          if (!this.settings.globalEnabled) return;

          // Use doc frontmatter to decide tracking (no vault read latency)
          if (!this.isTrackingOnByDoc(update.state.doc)) return;

          const head = update.state.selection.main.head;
          const whereNow = `@${this.offsetToLC(update.state.doc, head)}`;
          const oldDoc = update.startState.doc;

          // Skip edits inside frontmatter
          const fmEndLine0 = this.settings.skipFrontmatter
            ? this.getFrontmatterEndLine0(update.state.doc)
            : -1;
          const cursorLine0 = update.state.doc.lineAt(head).number - 1;
          if (this.settings.skipFrontmatter && fmEndLine0 >= 0 && cursorLine0 <= fmEndLine0) {
            return;
          }

          // time-based flush
          this.maybeFlushSentenceByTime(file);
          this.maybeFlushDeleteByTime(file);

          for (const tr of update.transactions) {
            if (!tr.docChanged) continue;

            const userEvent = tr.annotation(Transaction.userEvent) || "unknown";

            // UNDO/REDO flush buffers first
            if (userEvent.includes("undo")) {
              this.flushSentence(file);
              this.flushDelete(file);
              this.logAction(file, "UNDO", whereNow);
              continue;
            }
            if (userEvent.includes("redo")) {
              this.flushSentence(file);
              this.flushDelete(file);
              this.logAction(file, "REDO", whereNow);
              continue;
            }

            tr.changes.iterChanges((fromA, toA, _fromB, _toB, inserted) => {
              const deletedText = oldDoc.sliceString(fromA, toA);
              const insertedText = inserted.toString();

              const hasDel = deletedText.length > 0;
              const hasIns = insertedText.length > 0;

              // frontmatter change filter (by change start position)
              if (this.settings.skipFrontmatter && fmEndLine0 >= 0) {
                const changeLine0 = oldDoc.lineAt(fromA).number - 1;
                if (changeLine0 <= fmEndLine0) return;
              }

              // CUT: store only (do NOT log CUT). We will log MOVE if matched.
              if (userEvent.includes("cut")) {
                this.flushSentence(file);
                this.flushDelete(file);

                if (hasDel) {
                  const fromWhere = `@${this.offsetToLC(oldDoc, fromA)}`;
                  this.pendingCut = {
                    text: deletedText,
                    fromWhere,
                    at: Date.now(),
                    filePath: file.path,
                  };
                }
                return;
              }

              // PASTE: if matches pendingCut -> MOVE only
              if (userEvent.includes("paste")) {
                this.flushSentence(file);
                this.flushDelete(file);

                if (hasIns) {
                  const moved =
                    this.pendingCut &&
                    this.pendingCut.filePath === file.path &&
                    Date.now() - this.pendingCut.at <= this.settings.moveWindowMs &&
                    this.normalizeForMoveCompare(insertedText) ===
                      this.normalizeForMoveCompare(this.pendingCut.text);

                  if (moved) {
                    this.logMove(file, "MOVE", this.pendingCut.fromWhere, whereNow, insertedText);
                    this.pendingCut = null;
                  } else {
                    // normal paste
                    this.logDelta(file, "PASTE", whereNow, "+", insertedText);
                  }
                }
                return;
              }

              // REPL (replace): log as one event
              if (hasDel && hasIns) {
                this.flushSentence(file);
                this.flushDelete(file);
                this.logReplace(file, "REPL", whereNow, deletedText, insertedText);
                return;
              }

              // DEL only: merge into one DEL (not per char)
              if (hasDel && !hasIns) {
                this.flushSentence(file);
                if (deletedText === "\n") return; // ignore pure newline deletes
                this.feedDelete(file, whereNow, deletedText);
                return;
              }

              // TYPE only: sentence-level buffer
              if (!hasDel && hasIns) {
                if (insertedText === "\n") {
                  // newline ends the sentence buffer (but do not log the \n itself)
                  this.flushSentence(file);
                  return;
                }
                this.feedSentence(file, whereNow, insertedText);
                return;
              }
            });
          }

          // flush timers again
          this.maybeFlushSentenceByTime(file);
          this.maybeFlushDeleteByTime(file);
        } catch (e) {
          console.error("Writing Live Track error:", e);
        }
      })
    );

    console.log("Writing Live Track loaded");
  }

  onunload() {
    console.log("Writing Live Track unloaded");
  }

  // -------------------------
  // Tracking + Frontmatter
  // -------------------------
  isTrackingOnByDoc(doc) {
    const text = doc.toString();
    if (!text.startsWith("---")) return false;
    const end = text.indexOf("\n---", 3);
    if (end === -1) return false;
    const fm = text.slice(0, end + 4);
    return /(^|\n)writeTrack:\s*true(\s|\n|$)/.test(fm);
  }

  async isTrackingOnByVaultRead(file) {
    if (!this.settings.globalEnabled) return false;
    const text = await this.app.vault.read(file);
    if (!text.startsWith("---")) return false;
    const end = text.indexOf("\n---", 3);
    if (end === -1) return false;
    const fm = text.slice(0, end + 4);
    return /(^|\n)writeTrack:\s*true(\s|\n|$)/.test(fm);
  }

  getFrontmatterEndLine0(doc) {
    const text = doc.toString();
    if (!text.startsWith("---")) return -1;
    const end = text.indexOf("\n---", 3);
    if (end === -1) return -1;
    const upto = text.slice(0, end + 4);
    return upto.split("\n").length - 1;
  }

  // -------------------------
  // TYPE: sentence buffer
  // -------------------------
  getSent(file) {
    const key = file.path;
    let s = this.sentAgg.get(key);
    if (!s) {
      s = { text: "", where: "", lastAt: 0 };
      this.sentAgg.set(key, s);
    }
    return s;
  }

  feedSentence(file, where, insertedText) {
    const s = this.getSent(file);

    if (!s.where) s.where = where;
    s.lastAt = Date.now();

    s.text += insertedText;

    // flush on sentence-end punctuation
    if (this.sentenceEndRe.test(insertedText)) {
      this.flushSentence(file);
    }
  }

  maybeFlushSentenceByTime(file) {
    const s = this.getSent(file);
    if (!s.lastAt) return;
    if (s.text && Date.now() - s.lastAt > this.settings.sentenceGapMs) {
      this.flushSentence(file);
    }
  }

  flushSentence(file) {
    const s = this.getSent(file);
    if (!s.text) return;

    this.logDelta(file, "TYPE", s.where || "@L1C1", "+", s.text);

    s.text = "";
    s.where = "";
    s.lastAt = 0;
  }

  // -------------------------
  // DEL: merge buffer
  // -------------------------
  getDel(file) {
    const key = file.path;
    let d = this.delAgg.get(key);
    if (!d) {
      d = { text: "", where: "", lastAt: 0 };
      this.delAgg.set(key, d);
    }
    return d;
  }

  feedDelete(file, where, deletedText) {
    const d = this.getDel(file);

    // If we paused too long, flush the previous delete first
    this.maybeFlushDeleteByTime(file);

    if (!d.where) d.where = where;
    d.lastAt = Date.now();

    // Merge deletes into one chunk (prepend to preserve natural backspace direction)
    d.text = deletedText + d.text;

    // If deletion touches whitespace/punctuation, flush as a block
    if (/[ \t\n]|[.,!?;:"'()\[\]{}<>，。！？；：“”‘’（）【】《》]/.test(deletedText)) {
      this.flushDelete(file);
    }
  }

  maybeFlushDeleteByTime(file) {
    const d = this.getDel(file);
    if (!d.lastAt) return;
    if (d.text && Date.now() - d.lastAt > this.settings.editGapMs) {
      this.flushDelete(file);
    }
  }

  flushDelete(file) {
    const d = this.getDel(file);
    if (!d.text) return;

    this.logDelta(file, "DEL", d.where || "@L1C1", "-", d.text);

    d.text = "";
    d.where = "";
    d.lastAt = 0;
  }

  // -------------------------
  // Logging (colored HTML)
  // -------------------------
  escHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#39;");
  }

  span(color, text) {
    return `<span style="color:${color}">${text}</span>`;
  }

  fmtTs(d) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(
      d.getHours()
    )}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  fmtWhere(where) {
    return this.span(this.colors.pos, this.escHtml(where));
  }

  // action as plain text (theme-safe)
  fmtAction(action) {
    return this.escHtml(action);
  }

  fmtDelta(sign, text) {
    const clipped = this.clip(text);
    const safe = this.escHtml(clipped);
    const quoted = `"${safe}"`;

    if (sign === "+") return this.span(this.colors.plus, `+ ${quoted}`);
    if (sign === "-") return this.span(this.colors.minus, `- ${quoted}`);
    if (sign === "=") return this.span(this.colors.eq, `= ${quoted}`);
    return this.span(this.colors.action, quoted);
  }

  logAction(file, action, where) {
    const ts = this.span(this.colors.ts, this.fmtTs(new Date()));
    const line = `${ts} ${this.fmtAction(action)} ${this.fmtWhere(where)}`;
    this.enqueueLogLine(file, line);
  }

  logDelta(file, action, where, sign, text) {
    const ts = this.span(this.colors.ts, this.fmtTs(new Date()));
    const line = `${ts} ${this.fmtAction(action)} ${this.fmtWhere(where)} ${this.fmtDelta(
      sign,
      text
    )}`;
    this.enqueueLogLine(file, line);
  }

  logReplace(file, action, where, before, after) {
    const ts = this.span(this.colors.ts, this.fmtTs(new Date()));
    const left = this.span(this.colors.minus, `- "${this.escHtml(this.clip(before))}"`);
    const right = this.span(this.colors.plus, `+ "${this.escHtml(this.clip(after))}"`);
    const arrow = this.span(this.colors.action, "→");
    const line = `${ts} ${this.fmtAction(action)} ${this.fmtWhere(where)} ${left} ${arrow} ${right}`;
    this.enqueueLogLine(file, line);
  }

  logMove(file, action, fromWhere, toWhere, text) {
    const ts = this.span(this.colors.ts, this.fmtTs(new Date()));
    const pos = this.span(
      this.colors.pos,
      `${this.escHtml(fromWhere)}→${this.escHtml(toWhere.replace("@", ""))}`
    );
    const body = this.span(this.colors.eq, `= "${this.escHtml(this.clip(text))}"`);
    const line = `${ts} ${this.fmtAction(action)} ${pos} ${body}`;
    this.enqueueLogLine(file, line);
  }

  // -------------------------
  // Log file create/link
  // -------------------------
  async getOrCreateLogFile(noteFile) {
    const folderPath = noteFile.parent ? noteFile.parent.path : "";
    const logFolderPath = normalizePath(`${folderPath}/${this.settings.logFolderName}`);

    const folder = this.app.vault.getAbstractFileByPath(logFolderPath);
    if (!folder) await this.app.vault.createFolder(logFolderPath);

    const logPath = normalizePath(`${logFolderPath}/${noteFile.basename}.log.md`);
    const existing = this.app.vault.getAbstractFileByPath(logPath);
    if (existing instanceof TFile) return existing;

    return await this.app.vault.create(logPath, `# Log for ${noteFile.basename}\n\n`);
  }

  async ensureLogLinkInNote(noteFile) {
    const logFile = await this.getOrCreateLogFile(noteFile);
    const link = `[[${logFile.path.replace(/\.md$/i, "")}|📌 Writing Log]]`;

    const text = await this.app.vault.read(noteFile);
    if (text.includes(link)) return;

    const marker = "\n\n---\n";
    const newText = (text.endsWith("\n") ? text : text + "\n") + marker + link + "\n";
    await this.app.vault.modify(noteFile, newText);
  }

  // -------------------------
  // Write queue
  // -------------------------
  enqueueLogLine(file, line) {
    const key = file.path;
    let q = this.writeQueue.get(key);
    if (!q) {
      q = { lines: [], timer: null, writing: false };
      this.writeQueue.set(key, q);
    }

    q.lines.push(line);

    if (!q.timer) {
      q.timer = window.setTimeout(() => this.flushLog(file), this.settings.flushMs);
    }
  }

  async flushLog(file) {
    const key = file.path;
    const q = this.writeQueue.get(key);
    if (!q) return;

    if (q.timer) window.clearTimeout(q.timer);
    q.timer = null;

    if (q.writing || q.lines.length === 0) return;
    q.writing = true;

    try {
      const logFile = await this.getOrCreateLogFile(file);
      const old = await this.app.vault.read(logFile);

      // one log per line, no blank lines
      const append = q.lines.join("<br>\n") + "<br>\n";
      q.lines = [];
      await this.app.vault.modify(logFile, old + append);
    } finally {
      q.writing = false;
    }
  }

  // -------------------------
  // Utils
  // -------------------------
  offsetToLC(doc, offset) {
    const line = doc.lineAt(offset);
    const col = offset - line.from + 1;
    return `L${line.number}C${col}`;
  }

  clip(s) {
    const oneLine = String(s).replace(/\n/g, "↵");
    const max = this.settings.maxSnippet;
    return oneLine.length > max ? oneLine.slice(0, max) + "…" : oneLine;
  }

  normalizeForMoveCompare(s) {
    return String(s).replace(/\s+/g, " ").trim();
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
};

class WritingLiveTrackSettingTab {
  constructor(app, plugin) {
    this.app = app;
    this.plugin = plugin;
  }

  display() {
    const { containerEl } = this;
    containerEl.empty();

    containerEl.createEl("h2", { text: "Writing Live Track" });

    new Setting(containerEl)
      .setName("Global enable")
      .setDesc("Off = nothing is logged")
      .addToggle((t) =>
        t.setValue(this.plugin.settings.globalEnabled).onChange(async (v) => {
          this.plugin.settings.globalEnabled = v;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Skip frontmatter")
      .setDesc("Do not log frontmatter edits")
      .addToggle((t) =>
        t.setValue(this.plugin.settings.skipFrontmatter).onChange(async (v) => {
          this.plugin.settings.skipFrontmatter = v;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Sentence gap (ms)")
      .setDesc("Flush TYPE buffer when you pause")
      .addText((t) =>
        t.setValue(String(this.plugin.settings.sentenceGapMs)).onChange(async (v) => {
          const n = Number(v);
          if (!Number.isFinite(n) || n < 0) return;
          this.plugin.settings.sentenceGapMs = n;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Edit gap (ms)")
      .setDesc("Merge consecutive DEL into one")
      .addText((t) =>
        t.setValue(String(this.plugin.settings.editGapMs)).onChange(async (v) => {
          const n = Number(v);
          if (!Number.isFinite(n) || n < 0) return;
          this.plugin.settings.editGapMs = n;
          await this.plugin.saveSettings();
        })
      );

    new Setting(containerEl)
      .setName("Log folder name")
      .setDesc("Folder name for logs (per note folder)")
      .addText((t) =>
        t
          .setPlaceholder("log")
          .setValue(this.plugin.settings.logFolderName)
          .onChange(async (v) => {
            this.plugin.settings.logFolderName = (v || "log").trim() || "log";
            await this.plugin.saveSettings();
          })
      );

    new Setting(containerEl)
      .setName("Auto insert link")
      .setDesc("Insert a link to the log when enabling tracking")
      .addToggle((t) =>
        t.setValue(this.plugin.settings.autoInsertLink).onChange(async (v) => {
          this.plugin.settings.autoInsertLink = v;
          await this.plugin.saveSettings();
        })
      );
  }
}